<section class="cid-qUUUc0Sn5h" id="footer1-8">

    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-3">
                <div class="media-wrap">
                    <a href="<?php echo $SITE_PATH;?>home">
                        <img src="<?php echo $SITE_PATH;?>assets/images/logo1-210x82.png" alt="Mobirise" title="">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Address
                </h5>
                <p class="mbr-text">14,Aashirwad Shopping Center,
<br>Opp. Navneet Park,
<br>Harni Warsiya Ring Road,
<br>Gujarat,Vadodara - 390006
<br><br></p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">EMAIL US&nbsp;</h5>
                <p class="mbr-text">info@ambicacaterers.in
<br>Ambicacaterers@gmail.com</p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Contact Us</h5>
                <p class="mbr-text">Telephone :(0265)-2495578<br>Raju Bhai (M)<br>91 98240 17375 , 90990 27375<br>Dipu Bhai (M)&nbsp;98255 95315<br><br><br></p>
            </div>
        </div>
        
    </div>
</section>

<section once="" class="cid-qUUUf2Uml7 mbr-reveal" id="footer2-9">

    <div class="container">
        <div class="media-container-row align-center mbr-white">
            <div class="row row-links">
                <ul class="foot-menu">
                    
                    
                    
                    
                    
                <li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="mbr-bold text-info" href="<?php echo $SITE_PATH;?>home" target="_blank">Home</a>
                    </li><li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="mbr-bold text-info" href="<?php echo $SITE_PATH;?>About" target="_blank">About Us</a>
                    </li><li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="mbr-bold text-info" href="<?php echo $SITE_PATH;?>Service" target="_blank">Our Services</a>
                    </li><li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="mbr-bold text-info" href="<?php echo $SITE_PATH;?>Menu" target="_blank">Our Menu</a>
                    </li><li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="mbr-bold text-info" href="<?php echo $SITE_PATH;?>Gallery" target="_blank">Our Photo Gallery</a>
                    </li>
                    
                    <li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="mbr-bold text-info" href="<?php echo $SITE_PATH;?>Contact" target="_blank">Contact Us</a>
                    </li>
                    
                    </ul>
            </div>
            <div class="row social-row">
                <div class="social-list align-right pb-2">
                    
                    
                    
                    
                    
                    
                <div class="soc-item">
                        <a href="https://twitter.com/mobirise" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon" style="color: rgb(35, 35, 35);"></span>
                        </a>
                    </div><div class="soc-item">
                        <a href="https://www.facebook.com/pages/Mobirise/1616226671953247" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon" style="color: rgb(35, 35, 35);"></span>
                        </a>
                    </div><div class="soc-item">
                        <a href="https://www.youtube.com/c/mobirise" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon" style="color: rgb(35, 35, 35);"></span>
                        </a>
                    </div><div class="soc-item">
                        <a href="https://instagram.com/mobirise" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon" style="color: rgb(35, 35, 35);"></span>
                        </a>
                    </div></div>
            </div>
            <div class="row row-copirayt">
                <p class="mbr-text mb-0 mbr-fonts-style mbr-white align-center display-7">
                    © Copyright 2014 Ambicacaterers - All Rights Reserved
                </p>
            </div>
        </div>
    </div>
</section>



