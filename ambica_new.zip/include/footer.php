<div class="footer">

	<div class="footer-main wrap">

	<div class="footer-grids">

		<div class="fgrid">

			<h3>About Raju Joshi</h3>

			<p>Raju Joshi(Tikubhai): is passionate about working on upcoming wedding industries in India. This website deals with traditional Indian wedding Menus & Decoration in a auspicious occasion.</p>

			


</p>


<div class="social-media">
              <h3>Music <strong><button id="playpausebtn"></button><button id="mutebtn"></button></strong></h3>  
                <style>
				button{ border:none; cursor:pointer; outline:none; }
				button#playpausebtn{
					background:url(<?php echo $SITE_PATH;?>images/pause.png) no-repeat;
					width:50px;
					height:31px;
				}
				button#mutebtn{
					background:url(<?php echo $SITE_PATH;?>images/speaker.png) no-repeat;
					width:5px;
					height:14px;
				}
				</style>
				<!--<script>
                var audio, playbtn, mutebtn, seek_bar;
                function initAudioPlayer(){
                    audio = new Audio();
                    audio.src = "tamarin.mp3";
                    audio.loop = true;
                    audio.play();
                    // Set object references
                    playbtn = document.getElementById("playpausebtn");
                    mutebtn = document.getElementById("mutebtn");
                    // Add Event Handling
                    playbtn.addEventListener("click",playPause);
                    mutebtn.addEventListener("click", mute);
                    // Functions
                    function playPause(){
                        if(audio.paused){
                            audio.play();
                            playbtn.style.background = "url(<?php echo $SITE_PATH;?>images/pause.png) no-repeat";
                        } else {
                            audio.pause();
                            playbtn.style.background = "url(<?php echo $SITE_PATH;?>images/play.png) no-repeat";
                        }
                    }
                    function mute(){
                        if(audio.muted){
                            audio.muted = false;
                            mutebtn.style.background = "url(<?php echo $SITE_PATH;?>images/speaker.png) no-repeat";
                        } else {
                            audio.muted = true;
                            mutebtn.style.background = "url(<?php echo $SITE_PATH;?>images/Mute.png) no-repeat";
                        }
                    }
                }
                window.addEventListener("load", initAudioPlayer);
                </script>-->
		</div>
		</div>

		<div class="fgrid">

			<h3>About Caterers</h3>

				<div>

					<p>Great food is what we provide whatever the occasion. Whether it's a small dinner party, a wedding, a lunch meeting or a banquet for 5000 or more people. Ambica Caterers can take care of it for you.</p>

            <p>     We have famous & recognized halwaies and cook of Gujrati,Panjabi,Rajasthani in our pool to cook tasty 100% Pure Vegeterian Rajasthani & Punjabi and all type of indian food. We also have experienced Chefs for Chinese, Continental & Mexican and other International Cuisine.</p>

				</div>				

		</div>

		<div class="fgrid">

			<h3>contact us</h3>

			<p>		    14,Aashirwad Shopping Center,<br/>

                        Opp. Navneet Park,<br/>

						Harni Warsiya Ring Road,<br/>

						Gujarat,Vadodara - 390006<br/>

				   		Telephone :(0265)-2495578</p><br/>

				 	 	<h3>E-Mail</h3>

                        <p><a href="mailto:info@ambicacaterers.in">info@ambicacaterers.in</a><br/>

                        <a href="mailto:ambicacaterers@gmail.com">Ambicacaterers@gmail.com</a></p>

			<!--<h4>1,22,333,4444</h4>-->

				
        <div class="copy-right-right">

 


</div>


		</div>

		<div class="clear"> </div>

	</div>

</div>

</div>





<div class="copy-right">

			<div class="wrap">

				<div class="copy-right-left">

					<p>Ambikacaterers  2014 @ <a href="javascript:void(0)">Vadodara    All Rights Reserved</a> </p><br/>

                    <p><a href="http://ambicacaterers.in/">www.ambicacaterers.in</a></p>

				</div>
 

	



			</div>

			</div>