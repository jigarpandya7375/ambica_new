<div class="contact-right">
					<div class="side-bar">
				<div class="grid-right-headings">
					<h2><a href="javascript:void(0);">Owner</a></h2>
					<h6> </h6>
						<div class="clear"> </div>
				</div>
				<h2>Raju Joshi (Tikubhai) (Caterers)</h2>
                <br/>
                  <img src="<?php echo $SITE_PATH;?>images/owner2.jpg" height="90" style="border-radius: 20px;" width="100"/>
                <div class="clear"> </div>
                
                
                <div class="seach-links">
                <p><a href="javascript:void(0);">Mobile :+91 98240 17375</a></p>
                <p><a href="javascript:void(0);">Mobile :+91 90990 27375</a></p>
                </div>
                
				<div class="grid-right-headings">
					<h2><a href="javascript:void(0);">Owner</a></h2>
					<h6> </h6>
						<div class="clear"> </div>
				</div>
				<div class="seach-links">
				<p style="padding:0px;"><h2>Hemang Joshi (Dipubhai) (Decorators) </h2>
                <br/>
                <img src="<?php echo $SITE_PATH;?>images/owner1.jpg" height="90" style="border-radius: 20px;" width="100"/>
                <div class="clear"> </div>
                <div class="seach-links"><p><a href="javascript:void(0);">Mobile :+91 98255 95315</a></p></div>
                </p>
				</div>
				<!--<div class="grid-right-headings">
					<h2><a href="#">photogallery</a></h2>
					<h6> </h6>
						<div class="clear"> </div>
				</div>-->
				<!--<div class="gallery">
				<ul>
						<li><a href="#"> </a></li>	
						<li><a href="#"> </a></li>
						<li><a href="#"> </a></li>
						<li><a href="#"> </a></li>
						<li><a href="#"> </a></li>
						<li><a href="#"> </a></li>
						<li><a href="#"> </a></li>
						<li><a href="#"> </a></li>
					</ul>                   
				</div>-->
				</div>
			</div>