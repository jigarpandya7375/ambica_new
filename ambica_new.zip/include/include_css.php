<link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/tether/tether.min.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/dropdown/css/style.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/socicon/css/styles.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/theme/css/style.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/gallery/style.css">
  <link rel="stylesheet" href="<?php echo $SITE_PATH;?>assets/mobirise/css/mbr-additional.css" type="text/css">