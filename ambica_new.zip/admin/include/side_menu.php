               <div class="side-menu fl">

              

               <ul>

                  

                

               

				<?php 

				if($rites[0]=='1')

				{?>

                  

                <li><h3>Dashboard</h3></li>

                  <li><a href="welcome.php">Go To Dashboard</a></li>   

                 

                <!--  <li><a href="manage_faq.php">Manage FAQ</a></li>    -->

                  <!-- <li><a href="manage_user.php">Manage Web User</a></li>         -->                         

                 <?php

				}

				if($rites[1]=='1')

				{

				?> 

               <!--   <li><h3>Manage Admin Rites</h3></li>

                  <li><a href="admin_user.php">Manage Admin User</a></li>   
-->
                  

                        

                     

                    <!--<li><a href="mail_send1.php">Send Mail</a></li>-->

                 <?php

				}

				if($rites[2]=='1')

				{

				?>   

                <!-- <li><h3>Manage Blog</h3></li>

                  <li><a href="manage_blog.php">Manage Blog</a></li> -->

                     <li><h3>Manage Photo</h3></li>

                    <li><a href="manage_photo.php">Manage Photo Gallery </a></li>   

                 <?php

				}

				if($rites[3]=='1')

				{?>

                

                    <li><h3>Manage Menu</h3></li>

                    <li><a href="manage_category.php">Manage Menu Category</a></li>

                    <li><a href="sub_cate.php">Manage Sub-Category </a></li>   

                    

                    <!--  -->

                 <?php

				}

				if($rites[4]=='1')

				{

				?>   

                    

                      <li><h3>Manage Message</h3></li>

                     <li><a href="message.php">Manage Message</a></li>

                   <!-- <li><h3>FILE MANAGEMENT</h3></li>

                    <li><a href="manage_file.php">Manage Document </a></li>-->

                  <?php

				}

				if($rites[5]=='1')

				{

				?>  

                   <!-- <li><h3>MANAGE NEWSLETTER</h3></li>

                    <li><a href="manage_mail_content.php">Add NewsLetter Content</a></li>
-->
                 <!--   <li><a href="mail_send_all.php">Send Mail</a></li>-->

                 <!--   <li><a href="send_newsletter.php">Send Mail</a></li>
-->
                    

                <?php

				}

				if($rites[6]=='1')

				{?>

                

               <li><h3>CHECK YOUR MAIL</h3></li>

                    <li><a href="mail_id.php">Mail ID / PASSWORD</a></li>

                  <!--   <li><h3>Google Map</h3></li>

                    <li><a href="googl_route.php">Find Route In Map </a></li>-->

                 <?php

				}

				if($rites[7]=='1')

				{

				?>

                     <li><h3>Manage RSS</h3></li>

                    <li><a href="manage_rss.php">Manage RSS Feeds </a></li>

                    

                <?php 

				}

				?>

                  <!-- <li><h3>MANAGE Message</h3></li>

                     <li><a href="message.php">Manage Message</a></li>-->

                    <!--  <li><a href="add_recipe.php">Manage  Files </a></li>-->

                   

				<!--	

                    <li><h3>EVENT MANAGEMENT</h3></li>

                    <li><a href="manage_event.php">Manage Latest Event</a></li>-->

                    

                   

                   

					<!--<li><a href="message.php">Message Management</a></li>

					<li><a href="#">Fourth link</a></li>-->

				</ul>

				

			</div>