



<div id="header-with-tabs">



		



		<div class="page-full-width cf">



	



			<!--<ul id="tabs" class="fl">



				<li><a href="dashboard.html" class="active-tab dashboard-tab">Dashboard</a></li>



				<li><a href="page-full-width.html">Full width page</a></li>



				<li><a href="page-other.html">Other page elements</a></li>



			</ul>-->



            <div style="float:left;"><img src="<?php echo $SITE_PATH;?>assets/images/logo.png" alt="Ambicacaterers" height="80" width="250" /></div>



             <div style="float:right; margin-top:30px;">             



             <?php include('clock.php');?>



             



             </div>



			



			<!--<div style="margin-top:30px;"><center><font color="#000000"><?php echo breadcrumbs();?></font></center></div>-->



		</div> <!-- end full-width -->	







	</div>