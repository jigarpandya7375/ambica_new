<div id="footer">

		<p>&copy; Copyright 2013 <a href="javascript:void(0);">Ambicacaterers.in</a>&nbsp; All rights reserved.</p>
		<p><strong>Design &amp;</strong> Develop by <a href="http://www.stuffssharer.in" target="_blank">Jigar Pandya </a></p>
	
	</div>