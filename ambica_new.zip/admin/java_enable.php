
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to Sohamtech - Javascript Enable</title>
<link href="images/inb.css" rel="stylesheet" type="text/css" />

<style type="text/css">
<!--
body {
	font:12px arial;
}
li{list-style-type:none;}
.style1 {font-weight: bold}
a:link{font:normal 12px arial; color: #6D7F04;}
a:hover{font:normal 12x arial; color: #000;}
a:visited{font:normal 12px arial; color: #bed730;;}
-->
</style>

</head>
<body topmargin="0" leftmargin="0" rightmargin="0" marginheight="0" marginwidth="0">
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">

        <tr>
          <td height="300" valign="top"><table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td width="750" height="15"></td>
            </tr>
            <tr>
              <td height="1" bgcolor="#FFFFFF">
			  <table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a name="top" id="top"></a><br/>
     <div style="width:400px; height:100px; padding:10px; border:1px solid #CCC;">
      <a href="#ie">Internet Explorer 6 and above</a><br/>
      <!--a href="#netscape7x">Netscape 7.X</a><br/>
      <a href="#netscape6x">Netscape 6.X</a><br/-->
      <!--a href="#opera7x">Opera 7.X</a><br/-->
      <a href="#mozilla">Mozilla 3.6.X and above</a><br/>
	  <a href="#chrome">Google Chrome </a><br/>
      <!--<a href="#mozilla1x">Mozilla 1.X </a><br/>-->
	  
      </div>
<a name="ie" id="ie"></a><h3>Internet Explorer 6 and above </h3>
      <ul>
        <li>1.	Select <strong><em>Internet Options</em></strong> from the <span class="style1"><em>Tools</em> menu. </span></li>
        <li>2.	In <strong><em>Internet Options</em></strong> dialog box select the <strong><em>Security</em></strong> tab. </li>
        <li>3.	Click the <strong><em>Custom Level...</em></strong> button. The Security Settings dialog box will pop up. </li>
        <li>4.	Under <strong><em>Scripting</em></strong> category enable <strong><em>Active scripting</em></strong>. </li>
        <li>5.	Click <strong><em>OK</em></strong> twice to close out. </li>
        <li>6.	Click <strong><em>Refresh</em></strong>.</li>
      </ul>
      <!--a href="#top">Top</a><br/>
<a name="netscape7x" id="netscape7x"></a> <h3>Netscape 7.X</h3>
      <ul>
        <li>1.	Select <em><strong>Preferences</strong></em> from the <em><strong>Edit </strong></em>menu. </li>
        <li>2.	Click the arrow next to<em><strong> Advanced</strong></em>. </li>
        <li>3.	Click <em><strong>Scripts</strong></em> &amp;<em><strong> Plug-in</strong></em>. </li>
        <li>4.	Check Navigator beneath &quot;<em><strong>Enable JavaScript for</strong></em>&quot;. </li>
        <li>5.	Click <em><strong>OK</strong></em>. </li>
        <li>6.	Click <em><strong>Reload</strong></em>. </li>
      </ul>
      <a href="#top">Top</a><br/>
<a name="netscape6x" id="netscape6x"></a>   <h3>Netscape 6.X</h3>
      <ul>
        <li>1.	Select <em><strong>Preferences</strong></em> from the <em><strong>Edit </strong></em>menu. </li>
        <li>2.	Click <em><strong>Advanced </strong></em></li>
        <li>3.	Check <em><strong>Enable JavaScrip</strong></em>t for <em><strong>Navigator</strong> </em></li>
        <li>4.	Click <em><strong>OK</strong></em>. </li>
        <li>5.	Click <em><strong>Reload</strong></em>. </li>
      </ul>
      <a href="#top">Top</a><br/>
<a name="opera7x" id="opera7x"></a>      <h3>Opera 7.X</h3>
      <ul>
        <li>1.	Select <em><strong>Quick Preferences</strong></em> from the <em><strong>File</strong></em> menu. </li>
        <li>2.	Make sure <em><strong>Enable JavaScript</strong></em> is checked. </li>
        <li>3.	Click <em><strong>Reload</strong></em>. </li>
      </ul-->
      <a href="#top">Top</a><br/>
<a name="mozilla" id="mozilla"></a>  <h3>Mozilla 3.6.X and above</h3>
      <ul>
        <li>1.	Select <em><strong>Options</strong></em> from the <em><strong>Tools</strong></em> Menu</li>
        <li>2.	Select <em><strong>Content</strong></em> tab</li>
        <li>3.	Make sure <em><strong>Enable JavaScript</strong></em> is checked</li>
      </ul>
      <a href="#top">Top</a><br/>
<a name="chrome" id="chrome"></a>      <h3>Google Chrome </h3>
      <ul>
        <li>1.	Click the settings next to <em><strong>Address bar</strong></em>. </li>
        <li>2.	Click <em><strong>Settings</strong></em>. </li>
        <li>3.	Click on <em><strong>Show advanced settings...</strong></em></li>
        <li>4.	Click on <em><strong>Content Settings</strong></em> under <em>Privacy</em>. </li>
        <li>5.	Check <em><strong>Allow all sites to run JavaScript (recommended)</strong></em> under <em>Javascript</em>. </li>
		<li>6.	Click <em><strong>OK</strong></em>. </li>
      </ul>
	   <a href="#top">Top</a><br/>	  
<!--<a name="mozilla1x" id="mozilla1x"></a>      <h3>Mozilla 1.X </h3>
      <ul>
        <li>1.	Select <em><strong>Preferences</strong></em> from the <em><strong>Edit</strong></em> menu. </li>
        <li>2.	Click the arrow next to <em><strong>Advanced</strong></em>. </li>
        <li>3.	Click <em><strong>Scripts &amp; Plug-in</strong></em>. </li>
        <li>4.	Check <em><strong>Navigator</strong></em> beneath &quot;<em><strong>Enable JavaScript for</strong></em>&quot;. </li>
        <li>5.	Click <em><strong>OK</strong></em>. </li>
        <li>6.	Click <em><strong>Reload</strong></em>.</li>
      </ul>
	   <a href="#top">Top</a><br/>-->
	   <!--a name="safari" id="safari"></a> <h3>Safari 4.X </h3>
       <ul>
        <li>1.	Select <em><strong>Preferences</strong></em> from the <em><strong>Edit</strong></em> menu. </li>
        <li>2.	Click the <em><strong>Security tab</strong></em>. </li>
        <li>3.	Click <em><strong>Scripts &amp; Plug-in</strong></em>. </li>
        <li>4.	Check &quot;<em><strong>Enable JavaScript</strong></em>&quot;. </li>
        <li>5. Close <em><strong>Security</strong></em> window. </li>
        <li>6.	Close and reopen the <em><strong>browser</strong></em>.</li>
      </ul-->
      <!--a href="#top">Top</a--><br/><br/>
      <strong>Note:</strong> Instructions may vary with different browsers and operating systems. If you cannot locate the JavaScript settings, check the help topics for the browser being used. </td>
  </tr>
</table>
			  </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
        <td height="5" valign="top"></td>
      </tr>
     
    </table></td>
  </tr>
</table>
</body>
</html>
