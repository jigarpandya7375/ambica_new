<?php
ob_start();
session_start();
error_reporting(0);
require_once('classess/connection.php');
require_once('classess/function.php');
?>
<!DOCTYPE html>
<html >
<head>
 
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.7.7, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logo1-210x82.png" type="image/x-icon">
  <meta name="description" content="">
  <title>Home | Ambica </title>
  
  <?php include('include/include_css.php');?>
  
  
</head>
<body>
  

 <?php include('include/header.php');?>
 
 
<section class="engine"><a href="#"></a></section>

<section class="carousel slide cid-qUUZGim7O0" data-interval="false" id="slider1-h">

    <div class="full-screen"><div class="mbr-slider slide carousel" data-pause="true" data-keyboard="false" data-ride="carousel" data-interval="5000"><ol class="carousel-indicators"><li data-app-prevent-settings="" data-target="#slider1-h" class=" active" data-slide-to="0"></li><li data-app-prevent-settings="" data-target="#slider1-h" data-slide-to="1"></li><li data-app-prevent-settings="" data-target="#slider1-h" data-slide-to="2"></li></ol><div class="carousel-inner" role="listbox"><div class="carousel-item slider-fullscreen-image active" data-bg-video-slide="false" style="background-image: url(assets/images/mbr-1620x1080.jpg);"><div class="container container-slide"><div class="image_wrapper"><div class="mbr-overlay"></div><img src="<?php echo $SITE_PATH;?>assets/images/mbr-1620x1080.jpg"><div class="carousel-caption justify-content-center"><div class="col-10 align-center"><h2 class="mbr-fonts-style display-1">Inspired By Gujarati Cuisine</h2><p class="lead mbr-text mbr-fonts-style display-5">We Offered Best Gujarati Cuisine , Chinese Cuisine , Panjabi Cuisine
<br>As well as top other indian cuisine at afforadable Price...</p><div class="mbr-section-btn" buttons="0"><a class="btn display-4 btn-primary" href="<?php echo $SITE_PATH;?>Menu">Watch Our Menu</a> </div></div></div></div></div></div><div class="carousel-item slider-fullscreen-image" data-bg-video-slide="false" style="background-image: url(assets/images/mbr-12-1620x1080.jpg);"><div class="container container-slide"><div class="image_wrapper"><div class="mbr-overlay"></div><img src="assets/images/mbr-12-1620x1080.jpg"><div class="carousel-caption justify-content-center"><div class="col-10 align-left"><h2 class="mbr-fonts-style display-2">Your vision, Your event, Your way, Our efforts</h2><p class="lead mbr-text mbr-fonts-style display-5">our vision, Your event, Your way, Our Efforts Makes your event Perfect...</p></div></div></div></div></div><div class="carousel-item slider-fullscreen-image" data-bg-video-slide="false" style="background-image: url(assets/images/mbr-3-1620x1080.jpg);"><div class="container container-slide"><div class="image_wrapper"><div class="mbr-overlay"></div><img src="<?php echo $SITE_PATH;?>assets/images/mbr-3-1620x1080.jpg"><div class="carousel-caption justify-content-center"><div class="col-10 align-right"><h2 class="mbr-fonts-style display-2">Delicious Food. To fit your lifestyle.</h2><p class="lead mbr-text mbr-fonts-style display-5">We Provide&nbsp;Delicious and Hot, Food Just for You.<br>If their ingredients are better, why isn’t their Food better?<br></p></div></div></div></div></div></div><a data-app-prevent-settings="" class="carousel-control carousel-control-prev" role="button" data-slide="prev" href="#slider1-h"><span aria-hidden="true" class="mbri-left mbr-iconfont"></span><span class="sr-only">Previous</span></a><a data-app-prevent-settings="" class="carousel-control carousel-control-next" role="button" data-slide="next" href="#slider1-h"><span aria-hidden="true" class="mbri-right mbr-iconfont"></span><span class="sr-only">Next</span></a></div></div>

</section>

<section class="mbr-section content4 cid-qUVdz9VogA" id="content4-i">

    

    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
            
                <h2 class="align-center pb-3 mbr-fonts-style display-2"> Visit our New Wedding Website</h2>
                <h3 class="mbr-section-subtitle align-center mbr-light mbr-fonts-style display-5"> Our Rameshwardcoratos.in is basically Wedding Decorators website. It provides fresh approach to wedding planning.</h3>
                
            </div>
        </div>
    </div>
</section>

<section class="mbr-section content8 cid-qUVdHLa7YY" id="content8-j">

    

    <div class="container">
        <div class="media-container-row title">
            <div class="col-12 col-md-8">
                <div class="mbr-section-btn align-center"><a class="btn btn-primary display-4" href="http://rameshwardecorators.in" target="_blank"><img src="assets/images/m_vactor.png" height="30" width="30"/>Visit Our Websites</a></div>
            </div>
        </div>
    </div>
</section>

<section class="header6 cid-qUVeqC8iP6 mbr-parallax-background" id="header6-k">

    

    <div class="mbr-overlay" style="opacity: 0.4; background-color: rgb(0, 0, 0);">
    </div>

    <div class="container">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title align-center mbr-bold pb-3 mbr-fonts-style display-2">Taste the flavor of catering.</h1>
                <p class="mbr-text align-center pb-3 mbr-fonts-style display-5">
                    Our Moto is The perfect solution for any occasion.<br>Raju Joshi Says "A stylish event begins long before the guests arrive. It begins with masterful planning".  Our staff's Moto is "Teamwork Makes The Dreamwork".<br>
                </p>
                <div class="mbr-section-btn align-center"><a class="btn btn-md btn-primary display-4" href="<?php echo $SITE_PATH;?>Download/<?php echo base64_encode("Menu.PDF");?>">Download Our Full Menu</a></div>
            </div>
        </div>
    </div>

    
</section>

<section class="mbr-section article content9 cid-qUVfUK6KHC" id="content9-l">
    
     

    <div class="container">
        <div class="inner-container" style="width: 100%;">
            <hr class="line" style="width: 25%;">
            <div class="section-text align-center mbr-fonts-style display-1">Our Special Menu</div>
            <hr class="line" style="width: 25%;">
        </div>
        </div>
</section>

<section class="mbr-gallery mbr-slider-carousel cid-qUVg9Zzsnb" id="gallery1-m">

    

    <div>
        <div><!-- Filter --><!-- Gallery --><div class="mbr-gallery-row"><div class="mbr-gallery-layout-default"><div><div>
        
        
         
             <?php
			  $sql_cat="select * from ".$SUFFIX."category where status='ACTIVE' order by rand()limit 0,8";
			  $res_cat=mysql_query($sql_cat);
			  while($data=mysql_fetch_array($res_cat))
			  {			  
              ?>
            
        <div class="mbr-gallery-item mbr-gallery-item--p1" data-video-url="false" data-tags="Awesome">
        
        <div href="javascript:vodi(0);" data-slide-to="0" data-toggle="modal">
        <img src="<?php echo $SITE_PATH;?>category_images/<?php echo $data['cat_image'];?>" height="200" alt="" title="">
        
        <span class=""></span><span class="mbr-gallery-title mbr-fonts-style display-7"><a href="<?php echo $SITE_PATH;?>Details/<?php echo $data['cat_id'];?>" style="color:#FFF;"><?php echo $data['cat_name'];?></a></span></div></div>
        
        
         <?php
			 
		     }?> 
        
        
        </div></div>
     <div class="clearfix"></div></div></div>
        
        </div>
    </div>

</section>

<section class="carousel slide testimonials-slider cid-qUVguw2w48" id="testimonials-slider1-n">
    
    

    

    <div class="container text-center">
        <h2 class="pb-5 mbr-fonts-style display-2">
            Owners Quote's</h2>

        <div class="carousel slide" data-ride="carousel" role="listbox">
            <div class="carousel-inner">
                
                
            <div class="carousel-item">
                    <div class="user col-md-8">
                        <div class="user_image">
                            <img src="assets/images/owner2-200x186.jpg" alt="" title="">
                        </div>
                        <div class="user_text pb-3">
                            <p class="mbr-fonts-style display-7">
                                We Serves delicious Gujarati , Panjabi, Chinese, continental , European cuisine. The surroundings are created in a nice way to give a glimpse of Gujarat, a historically rich state in India.
                            </p>
                        </div>
                        <div class="user_name mbr-bold pb-2 mbr-fonts-style display-7">Raju Joshi (Tiku Bhai)</div>
                        
                    </div>
                </div><div class="carousel-item">
                    <div class="user col-md-8">
                        <div class="user_image">
                            <img src="assets/images/owner1-200x199.jpg" alt="" title="">
                        </div>
                        <div class="user_text pb-3">
                            <p class="mbr-fonts-style display-7">Owner Says "<strong>Extroadinary weddings don’t just happen, they are planned.</strong>" 
<br>Our primary purpose of making the wedding day as special as their clients envision it to be.</p>
                        </div>
                        <div class="user_name mbr-bold pb-2 mbr-fonts-style display-7">Hemang Joshi ( Dipu Bhai )</div>
                        
                    </div>
                </div></div>

            <div class="carousel-controls">
                <a class="carousel-control-prev" role="button" data-slide="prev">
                  <span aria-hidden="true" class="mbri-arrow-prev mbr-iconfont"></span>
                  <span class="sr-only">Previous</span>
                </a>
                
                <a class="carousel-control-next" role="button" data-slide="next">
                  <span aria-hidden="true" class="mbri-arrow-next mbr-iconfont"></span>
                  <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</section>


<?php include('include/footer2.php'); ?>
<


<?php include('include/include_js.php') ?>




 
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>