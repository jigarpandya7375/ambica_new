<?php
ob_start();
session_start();
error_reporting(0);
require_once('classess/connection.php');
require_once('classess/function.php');
?>
<!DOCTYPE html>
<html >
<head>
 
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.7.7, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logo1-210x82.png" type="image/x-icon">
  <meta name="description" content="">
  <title>Home | Ambica </title>
  
  <?php include('include/include_css.php');?>
  
  
</head>
<body>
  

 <?php include('include/header.php');?>
 
 
<section class="engine"><a href="https://mobirise.me/j">website templates</a></section><section class="cid-qUVpc0Vi3k mbr-parallax-background" id="header2-q">

    

    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(35, 35, 35);"></div>

    <div class="container align-center">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-2">Does Food matter? How important food to Spreed happiness.</h1>
                
                
                <div class="mbr-section-btn"><a class="btn btn-md btn-primary display-4" href="https://mobirise.com">LEARN MORE</a></div>
            </div>
        </div>
    </div>
    <div class="mbr-arrow hidden-sm-down" aria-hidden="true">
        <a href="#next">
            <i class="mbri-down mbr-iconfont"></i>
        </a>
    </div>
</section>

<section class="mbr-section article content9 cid-qUVpv3Zbze" id="content9-t">
    
     

    <div class="container">
        <div class="inner-container" style="width: 100%;">
            <hr class="line" style="width: 25%;">
            <div class="section-text align-center mbr-fonts-style display-5">
                    Catering industry organization Catersource has acknowledged these companies as the leaders in their markets, and trendsetters in the industry. Through proven creativity and best business practices, they have risen to the top of their markets by consistently delivering superior results for their clients and guests.  
                </div>
            <hr class="line" style="width: 25%;">
        </div>
        </div>
</section>

<section class="timeline2 cid-qUVpBwlWIt" id="timeline2-u">

    

    

    <div class="container align-center">
        <h2 class="mbr-section-title pb-3 mbr-fonts-style display-2">
            ABOUT AMBICACATERER'S
        </h2>
        <h3 class="mbr-section-subtitle pb-5 mbr-fonts-style display-5">
            We pride ourselves on taking that extra step to make sure you and your guests are completely satisfied.
            
        </h3>

        <div class="container timelines-container" mbri-timelines="">
            <div class="row timeline-element reverse separline">      
                <span class="iconsBackground">
                    <span class="mbr-iconfont mbri-user"></span>
                </span>          
                <div class="col-xs-12 col-md-6 align-left">
                    <div class="timeline-text-content">
                        <h4 class="mbr-timeline-title pb-3 mbr-fonts-style display-5">
                         <img src="assets/images/owner2-1-200x186.jpg" alt="" height="80" width="80"style="border-radius: 80px; border: inset 5px #333;" title="">
                            Raju Joshi(Tiku Bhai) 
                            
                        </h4>
                        <p class="mbr-timeline-text mbr-fonts-style display-7">
                          We provide best services since 2010 and our moto is your Weddings and Commitment Ceremonies are inspired by you and we believe your food should be too. We are a full service custom caterer which means we'll manage your catering details from beginning to end. We'll create a personalized menu and handle your bar service as well as all of your staffing needs.
                        </p>
                        
                        
                     </div>
                </div>
            </div>

            <div class="row timeline-element  separline">
                <span class="iconsBackground">
                    <span class="mbr-iconfont mbri-user"></span>
                </span>
              <div class="col-xs-12 col-md-6 align-left ">
                    <div class="timeline-text-content">
                        <h4 class="mbr-timeline-title pb-3 mbr-fonts-style display-5">
                            <img src="assets/images/owner1-200x199.jpg" alt="" height="80" width="80"style="border-radius: 80px; border: inset 5px #333;" title="">
                            Hemang Joshi (Dipu Bhai)
                        </h4>
                        <p class="mbr-timeline-text mbr-fonts-style display-7">
                            This website deals with Decoration in any auspicious occasion like Marraige, Reception , Birthday Party and Many More.
                            
We provide all types of Decoration Items for Marrriage, Reception , Birthday party & and any kind of Occassion.

                        </p>
                    </div>
                </div>
            </div> 

            <div class="row timeline-element reverse">
                <span class="iconsBackground">
                    <span class="mbr-iconfont mbri-delivery"></span>
                </span>
              <div class="col-xs-12 col-md-6 align-left">
                    <div class="timeline-text-content">
                        <h4 class="mbr-timeline-title pb-3 mbr-fonts-style display-5">
                            HOW WE DIFFER FROM OTHERS
                        </h4>      
                        <p class="mbr-timeline-text mbr-fonts-style display-7">
                        <li>Custom Menus and Concepts</li>
                        <li>Amazing Professional Chefs</li>
                        <li>Gracious, Hospitable Staff</li>
                        <li>Clean as a Whistle</li>
                        <li>Great Flexibility</li>
                            
                        </p>
                    </div>
                </div>
            </div>

            
            

            

            

            

            

            

            

            

            
        </div>
    </div>
</section>

<section class="testimonials3 cid-qUVACkS9Oj" id="testimonials3-1j">

    

    

    <div class="container">
        <div class="media-container-row">
            <div class="media-content px-3 align-self-center mbr-white py-2">
            
            <p class="mbr-text testimonial-text mbr-fonts-style display-7">
                  <h1 style="color:#000;">Owner's Desk</h1>
                </p>
                
                <p class="mbr-text testimonial-text mbr-fonts-style display-7">
                   We Serves delicious Gujarati , Panjabi, Chinese, continental , European cuisine. The surroundings are created in a nice way to give a glimpse of Gujarat, a historically rich state in India.
                </p>
                <p class="mbr-author-name pt-4 mb-2 mbr-fonts-style display-7">
                   Raju Joshi (Tikubhai) (Caterers)
                </p>
                <p class="mbr-author-desc mbr-fonts-style display-7">
                    Mobile No:+91 98240 17375 , 90990 27375
                </p>
                
                <p class="mbr-author-name pt-4 mb-2 mbr-fonts-style display-7">
                   Hemang Joshi (Dipubhai) (Decorators)
                </p>
                <p class="mbr-author-desc mbr-fonts-style display-7">
                    Mobile :+91 98255 95315
                </p>
            </div>

            <div class="mbr-figure pl-lg-5" style="width: 50%;">
              <img src="<?php echo $SITE_PATH;?>assets/images/owner2-1-200x186.jpg" style="border-radius: 20px; border: inset 5px #333;" alt="" title="">
            </div>
        </div>
    </div>
</section>



<?php include('include/footer2.php'); ?>



<?php include('include/include_js.php') ?>
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>